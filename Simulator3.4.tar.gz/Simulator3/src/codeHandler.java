
public class codeHandler {
	private int getSensorValue(String sensor) {
		return 0;
	}
	
	
	public void runCode() {
		while(true) {
			
		}
	}
}

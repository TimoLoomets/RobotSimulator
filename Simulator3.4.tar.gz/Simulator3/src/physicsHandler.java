import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class physicsHandler {
	private Float[] forceSum = {0f, 0f};
	private Float torqueSum = 0f;
	private List<Map<String,Float[]>> frictionForces = new  ArrayList<Map<String,Float[]>>();
	
	private Float mass;
	private Float[] centerOfMassLocation;
	private Float[] speed = {0f, 0f};
	private Float rotation;
	private Float rotationSpeed = 0f;
	private Float rotationalInertia = 0f;
	private Float g = 9.80665f;
	
	
	public physicsHandler(Float imass, Float[] icenterOfMassLocation, Float irotation, Float irotationalInertia) {
		mass = imass;
		centerOfMassLocation = icenterOfMassLocation;
		rotation = irotation;
		rotationalInertia = irotationalInertia;
	}
	
	
	private Float pyt(Float a, Float b) {
		return (float) Math.sqrt(Math.pow(a, 2) + Math.pow(b, 2));
	}
	private Float[] normalise(Float[] vector) {
		return new Float[] {vector[0] / pyt(vector[0], vector[1]), vector[1] / pyt(vector[0], vector[1])};
	}
	private Float dot_product(Float[] vector1, Float[] vector2) {
		return vector1[0]*vector2[0] + vector1[1]*vector2[1];
	}
	private double[] rotateVector(double x, double y, double radians)//rotates a vector by the given amount of radians. The locations of motors are given in the format of {x, y} so they could be rotated.
    {
        double[] result = new double[2];
        result[0] = x * Math.cos(radians) - y * Math.sin(radians);
        result[1] = x * Math.sin(radians) + y * Math.cos(radians);
        return result;
    }
	private Float[] doubleToFloat1D(double[] input){//converts 1 dimensional double array to a 1 dimensional Float array.
        Float[] output = new Float[input.length];
        for(int i=0; i<input.length; i++){
            output[i] = (float) input[i];
        }
        return output;
    }
	
	
	private void frictionCalc() {
		List<Map<String,Float[]>> frictionForcesCurrent = new  ArrayList<Map<String,Float[]>>();
		for(Map<String,Float[]> friction : frictionForces) {
			Float[] maxFriction = friction.get("maxFriction");
			maxFriction = doubleToFloat1D(rotateVector(maxFriction[0], maxFriction[1], -rotation));
			
		}
	}
	
	
	public void forceAdd(Float[] forceLocation,	Float[] force) {
		for(int i=0; i<forceSum.length; i++) {
			forceSum[i] += force[i];
		}
		Float[] locationVector = {forceLocation[0] - centerOfMassLocation[0], forceLocation[1] - centerOfMassLocation[1]};
		Float distance = pyt(locationVector[0], locationVector[1]);
		torqueSum += (float) (pyt(force[0], force[1]) * distance * Math.sin(Math.acos(dot_product(normalise(force), normalise(forceLocation)))));
	}
	
	
	public void positionCalc(Float time) {
		/*for(Map<String,Float[]> friction : frictionForces) {
			Set<String> keys = friction.keySet();
			for(String key : keys) {
				System.out.print(key);
				System.out.println(Arrays.toString(friction.get(key)));
			}
		}
		System.out.println(frictionForces);*/
		for(int i=0; i<centerOfMassLocation.length; i++) {
			centerOfMassLocation[i] = (float) (centerOfMassLocation[i] + speed[i]*time + (forceSum[i]/mass)*Math.pow(time, 2)/2);
			speed[i] = speed[i] + (forceSum[i]/mass) * time;
		}
		rotation = (float) (rotation + rotationSpeed*time + torqueSum/rotationalInertia*Math.pow(time, 2)/2);
		rotationSpeed = rotationSpeed + torqueSum * time;
	}
	
	
	public void addFriction(Float[] location, Float[] maxFriction) {
		Map<String, Float[]> frictionForce = new HashMap<String, Float[]>();
		maxFriction = new Float[] {maxFriction[0] * mass * g, maxFriction[1]  * mass * g};
		frictionForce.put("location", location);
		frictionForce.put("maxFriction", maxFriction);
		frictionForces.add(frictionForce);
	}
	
	
	public void flush() {
		forceSum = new Float[]{0f, 0f};
		torqueSum = 0f;
	}
	public Float[] getForce() {
		return forceSum;
	}
	public Float getTorque() {
		return torqueSum;
	}
	public Float[] getLocation() {
		return centerOfMassLocation;
	}
	public Float getRotation() {
		return rotation;
	}
}

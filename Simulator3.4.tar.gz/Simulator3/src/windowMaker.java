import java.util.Arrays;

import javax.swing.JFrame;


public class windowMaker extends JFrame implements Runnable{
	protected windowDraw myWindowDraw = new windowDraw();
    robotHandler myRobotHandler;
    trackHandler myTrackHandler;
    int pixelsPerMeter = 333;
    
    public windowMaker(){
        super();
        myRobotHandler = new robotHandler();
        myTrackHandler = new trackHandler();
        
        myWindowDraw.setTrack(myTrackHandler.getTrackImage(), new int[] {(int) Math.round(1.5 * pixelsPerMeter), Math.round(3 * pixelsPerMeter)});
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(1000, 1000);
        this.setTitle("Simulator");
        this.setContentPane(myWindowDraw);
        this.setVisible(true);
        
    }
    

    public void run() {
        try {
            Thread.sleep(10);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        myTrackHandler.darknessCalc();
        Float time = 0.00001f;
        while(true) {
        	myRobotHandler.foo();
        	myRobotHandler.move(time);
			int[][] displayPoints = myRobotHandler.getDisplayPoints(this.getWidth(), this.getHeight(), pixelsPerMeter);
			int[] Location = myRobotHandler.getCOM(this.getWidth(), this.getHeight(), pixelsPerMeter);
			myWindowDraw.refresh(displayPoints, Location);
        	this.repaint();
        	System.out.println(Arrays.toString(Location));
        }
    }
}

import org.json.*;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class robotHandler {
    private JSONObject robot;
    physicsHandler myPhysicsHandler;
    Float[] robotLocation;
    Float robotRotation;
    Float[][] body;
    Float[][] bodyPoints;
    Float[][] bodyLocations;
    Float[][] bodyPointsLocations;
    Map<String, Float[][]> motors = new HashMap<String, Float[][]>();
    
    private int maxLength(Float[][] input) {//get the length of longest array in a 2d Float array
    	return Arrays.stream(input).mapToInt(row -> row.length).max().getAsInt();
    }
    private Float[][] clockwiser(Float[][] input){//return the inserted vectors sorted in a clockwise rotational order
    	Float[][] output = new Float[input.length][maxLength(input)];
    	double[] angles = new double[input.length];
    	
    	for(int i=0; i<input.length; i++) {
    		angles[i] = Math.atan2((double) input[i][0], (double) input[i][1]);
    	}
    	
    	Arrays.sort(angles); 
    	for(Float[] point:input) {
    		double angle = Math.atan2(point[0], point[1]);
    		int myIndex = (int) Arrays.binarySearch(angles, angle);
    		
    		while(output[myIndex][0] != null){
    			myIndex++;
    		}
    		output[myIndex][0] = point[0];
    		output[myIndex][1] = point[1];
    	}
    	return output;
    }
    private int[][] floatToInteger2D(Float[][] input){//converts 2 dimensional Float array to a 2 dimensional int array (uses Math.round() to round the numbers).
        int[][] output = new int[input.length][maxLength(input)];
        for(int i=0; i<input.length; i++){
            for(int j=0; j<input[i].length; j++){
                output[i][j] = (int) Math.round(input[i][j]);
            }
        }
        return output;
    }
    private Float[] doubleToFloat1D(double[] input){//converts 1 dimensional double array to a 1 dimensional Float array.
        Float[] output = new Float[input.length];
        for(int i=0; i<input.length; i++){
            output[i] = (float) input[i];
        }
        return output;
    }
    private double[] rotateVector(double x, double y, double radians)//rotates a vector by the given amount of radians. The locations of motors are given in the format of {x, y} so they could be rotated.
    {
        double[] result = new double[2];
        result[0] = x * Math.cos(radians) - y * Math.sin(radians);
        result[1] = x * Math.sin(radians) + y * Math.cos(radians);
        return result;
    }
    private Float[][] rotateRobotPoints(Float[][] inputPoints, double radians){//rotates all of the motors by the given amount of radians and returns the result coordinates in the format of {x coordinates, y coordinates}.
        Float [][] output = new Float[inputPoints.length][maxLength(inputPoints)];
        
        for(int i=0; i<inputPoints[0].length; i++){
            Float[] newVector = doubleToFloat1D(rotateVector(inputPoints[0][i],inputPoints[1][i],-radians));
            output[0][i] = newVector[0];
            output[1][i] = newVector[1];
        }
        return output;
    }
    private Float[][] rotateRobot(Float[][] input, double radians){
    	Float [][] output = new Float[input.length][maxLength(input)];
    	for(int i=0; i<input.length; i++) {
    		Float[] newVector = doubleToFloat1D(rotateVector(input[i][0],input[i][1],-radians));
    		output[i][0] = newVector[0];
    		output[i][1] = newVector[1];
    	}
    	return output;
    }
    private void bodyCalc() {
    	List<Float[]> points = new ArrayList<>();
        Iterator keys = robot.keys();

        while(keys.hasNext()) {//get all the motor locations from the JSONObject robot and put them in the list points in the format of {{x0,y0},{x1,y1},{x2,y2}...
            String key = (String)keys.next();
            try {
				if (robot.get(key).getClass() == JSONObject.class) {
					JSONObject currentObject = (JSONObject)robot.get(key);
					if(currentObject.getString("type").toString().trim().equals("motor")) {
				        JSONArray location = (JSONArray) currentObject.get("location");
				        Float[] loc = {(float) location.optDouble(0),(float) location.optDouble(1)};
				        points.add(loc); 
					}
				}
			} catch (JSONException e) {
				e.printStackTrace();
			}
        } 
        
        Float[][] pointsFinal = new Float[2][points.size()];
        pointsFinal = points.toArray(pointsFinal);
        
        pointsFinal = clockwiser(pointsFinal);
        //System.out.println(Arrays.deepToString(pointsFinal));
        //System.out.println(robotRotation);
        pointsFinal = rotateRobot(pointsFinal,robotRotation);
        body = pointsFinal;
        
        Float[] xPointsResult = new Float[pointsFinal.length];
        Float[] yPointsResult = new Float[pointsFinal.length];
        for(int i=0; i<pointsFinal.length; i++) {
        	xPointsResult[i] = pointsFinal[i][0];
        	yPointsResult[i] = pointsFinal[i][1];
        }
        bodyPoints = new Float[][]{xPointsResult,yPointsResult};
    }
    private void bodyLocationsCalc() {
    	bodyLocations = new Float[body.length][maxLength(body)];
    	for(int i=0; i<body.length; i++) {
    		for(int j=0; j<robotLocation.length; j++) {
    			bodyLocations[i][j] = body[i][j] + robotLocation[j];
    		}
    	}
    	Float[] xPointsResult = new Float[bodyLocations.length];
        Float[] yPointsResult = new Float[bodyLocations.length];
        for(int i=0; i<bodyLocations.length; i++) {
        	xPointsResult[i] = bodyLocations[i][0];
        	yPointsResult[i] = bodyLocations[i][1];
        }
        bodyPointsLocations = new Float[][]{xPointsResult,yPointsResult};
    }
    private void motorsCalc() {
    	Iterator keys = robot.keys();
    	while(keys.hasNext()) {//get all the motor locations from the JSONObject robot and put them in the HashMap motors in the format of <motorName, {{location x, location y}, {direction x, direction y}}>
            String key = (String)keys.next();
            try {
				if (robot.get(key).getClass() == JSONObject.class) {
					JSONObject currentObject = (JSONObject)robot.get(key);
					if(currentObject.getString("type").toString().trim().equals("motor")) {
				        JSONArray location = (JSONArray) currentObject.get("location");
				        Float[] loc = doubleToFloat1D(rotateVector((double) location.optDouble(0),(double) location.optDouble(1), -robotRotation));
				        loc = new Float[] {loc[0] + robotLocation[0], loc[1] + robotLocation[1]};
				        JSONArray direction = (JSONArray) currentObject.get("direction");
				        Float[] dir = doubleToFloat1D(rotateVector((double) direction.optDouble(0),(double) direction.optDouble(1), -robotRotation));
				        motors.put(key, new Float[][]{loc,dir});
					}
				}
			} catch (JSONException e) {
				e.printStackTrace();
			}
        } 
    }
    private void update() {
    	robotLocation = myPhysicsHandler.getLocation();
    	robotRotation = myPhysicsHandler.getRotation();
    	bodyCalc();
    	bodyLocationsCalc();
    	motorsCalc();
    	//System.out.println(motors);
    }
    
    
    public robotHandler() {
    	buildReader myBuildReader = new buildReader();
    	try {
			robot = myBuildReader.reader2("Information/build.json").getJSONObject("robot");
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		} catch (JSONException e1) {
			e1.printStackTrace();
		}
    	robotLocation = new Float[]{1f, 1f};//robots initial location in meters
        robotRotation = (float) Math.PI * 0f;//robots rotation in radians
        //System.out.println(robotRotation);
        JSONObject centerOfMass;
		try {
			centerOfMass = (JSONObject) robot.get("center of mass");
			JSONArray centerOfMassLocation = (JSONArray) centerOfMass.get("location");
			myPhysicsHandler = new physicsHandler((float) centerOfMass.getDouble("mass"), new Float[]{(float) centerOfMassLocation.optDouble(0)+robotLocation[0], (float) centerOfMassLocation.optDouble(1)+robotLocation[1]}, robotRotation);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		update();
    }
    
    
    public int[][] getDisplayPoints(int winWidth, int winHeight, int pixelsPerMeter){
    	Float [][] points = bodyPointsLocations.clone();

        for(int i=0; i<points.length; i++){
            for(int j=0; j<points[i].length; j++){
                points[i][j] = points[i][j] * pixelsPerMeter;
            }
        }

        int[][] robotLoc = floatToInteger2D(points);//makes all the location number int so they could be displayed.
        for(int i=0; i<robotLoc[1].length; i++){//flips the y-axis so the 0,0 would be in the bottom left (makes it more logical to look at).
            robotLoc[1][i] = winHeight-robotLoc[1][i];
        }
    	return robotLoc;
    }
    
    public void move(Float time) {
    	myPhysicsHandler.positionCalc(time);
    	myPhysicsHandler.flush();
    	update();
    	//System.out.println(Arrays.deepToString(robotLocation));
    }
    
    public void foo() {
    	
		myPhysicsHandler.forceAdd(motors.get("motor1")[0], motors.get("motor1")[1]);//new Float[]{1f,1f} 
		myPhysicsHandler.forceAdd(motors.get("motor2")[0], motors.get("motor2")[1]);
		myPhysicsHandler.forceAdd(motors.get("motor3")[0], motors.get("motor3")[1]);
    }
}
import java.util.Arrays;

import javax.swing.JFrame;

import org.json.JSONException;
import org.json.JSONObject;

public class windowMaker extends JFrame implements Runnable{
	protected windowDraw myWindowDraw = new windowDraw();
    robotHandler myRobotHandler;
    int pixelsPerMeter = 500;
    
    public windowMaker(){
        super();
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(1000, 1000);
        this.setTitle("Simulator");
        this.setContentPane(myWindowDraw);
        this.setVisible(true);
        this.repaint();
        myRobotHandler = new robotHandler();
    }
    

    public void run() {
        try {
            Thread.sleep(10);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        
        Float time = 0.01f;
        int roundCounter = 0;
        while(true) {
        	myRobotHandler.foo();
        	myRobotHandler.move(time);
			int[][] displayPoints = myRobotHandler.getDisplayPoints(this.getWidth(), this.getHeight(), pixelsPerMeter);
			//System.out.println(Arrays.deepToString(displayPoints));
			myWindowDraw.refresh(displayPoints);
        	this.repaint();
        }
    }
}

import java.io.FileNotFoundException;

import org.json.JSONException;
import org.json.JSONObject;

public class Main {

	public static void main(String[] args) throws FileNotFoundException, JSONException {
		windowMaker mainWindow = new windowMaker();
        new Thread(mainWindow, "Window").start();
	}
}

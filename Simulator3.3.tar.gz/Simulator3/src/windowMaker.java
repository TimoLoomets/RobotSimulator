import javax.swing.JFrame;


public class windowMaker extends JFrame implements Runnable{
	protected windowDraw myWindowDraw = new windowDraw();
    robotHandler myRobotHandler;
    int pixelsPerMeter = 500;
    
    public windowMaker(){
        super();
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(1000, 1000);
        this.setTitle("Simulator");
        this.setContentPane(myWindowDraw);
        this.setVisible(true);
        //this.repaint();
        myRobotHandler = new robotHandler();
    }
    

    public void run() {
        try {
            Thread.sleep(10);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        
        //long myTime = System.currentTimeMillis();
        Float time = 0.01f;
        //int roundCounter = 0;
        while(true) {
        	myRobotHandler.foo();
        	myRobotHandler.move(time);
			int[][] displayPoints = myRobotHandler.getDisplayPoints(this.getWidth(), this.getHeight(), pixelsPerMeter);
			int[] Location = myRobotHandler.getCOM(this.getWidth(), this.getHeight(), pixelsPerMeter);
			myWindowDraw.refresh(displayPoints, Location);
        	this.repaint();
        	/*long dif = System.currentTimeMillis() - myTime;
        	if(dif != 0) {
        		System.out.println(1000/dif);
        	}
        	else{
        		System.out.println("dif < 0");
        	}
        	myTime = System.currentTimeMillis();*/
        }
    }
}

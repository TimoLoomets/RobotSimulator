import java.awt.Color;
import java.awt.Graphics;
import java.util.Arrays;

import javax.swing.JPanel;

public class windowDraw extends JPanel{
    int[] xPoints = {};
    int[] yPoints = {};
    int nP = xPoints.length;//I didn't quie understand what this variable are for, but it seems to work like this.
    int[] Loc = {0,0};

    
    public void refresh(int[][] points, int[] point) {
    	xPoints = new int[points[0].length];
    	xPoints = points[0];
    	yPoints = new int[points[1].length];
    	yPoints = points[1];
    	nP = xPoints.length;
    	Loc = new int[point.length];
    	Loc = point;
    }
    
    protected void paintComponent(Graphics g) {
        g.setColor(Color.WHITE);
        g.fillRect(0, 0, this.getWidth(), this.getHeight());
        g.setColor(Color.RED);
        g.fillPolygon(xPoints,yPoints,nP);
        g.setColor(Color.BLUE);
        //g.drawLine(Loc[0], Loc[1], Loc[0], Loc[1]);
        //System.out.println(Arrays.toString(Loc));
        g.drawOval(Loc[0]-5, Loc[1]-5, 10, 10);
    }
}

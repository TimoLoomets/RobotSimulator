import java.util.Arrays;

public class physicsHandler {
	private Float[] forceSum = {0f, 0f};
	private Float torqueSum = 0f;
	
	private Float mass;
	private Float[] centerOfMassLocation;
	private Float[] speed = {0f, 0f};
	private Float rotation;
	private Float rotationSpeed = 0f;
	
	
	public physicsHandler(Float imass, Float[] icenterOfMassLocation, Float irotation) {
		mass = imass;
		centerOfMassLocation = icenterOfMassLocation;
		rotation = irotation;
	}
	
	
	private Float pyt(Float a, Float b) {
		return (float) Math.sqrt(Math.pow(a, 2)+Math.pow(b, 2));
	}
	
	
	public void forceAdd(Float[] forceLocation,	Float[] force) {
		for(int i=0; i<forceSum.length; i++) {
			forceSum[i] += force[i];
		}
		Float[] locationVector = {forceLocation[0] - centerOfMassLocation[0], forceLocation[1] - centerOfMassLocation[1]};
		Float distance = pyt(locationVector[0], locationVector[1]);
		Float totalForce = pyt(force[0],force[1]);
		Float[] perpendicularVector = {-locationVector[1]*totalForce/distance, locationVector[0]*totalForce/distance};
		Float perpendicularForce = force[0]*perpendicularVector[0] + force[1]*perpendicularVector[1];
		torqueSum -= perpendicularForce*distance;
	}
	
	
	public void positionCalc(Float time) {
		for(int i=0; i<centerOfMassLocation.length; i++) {
			centerOfMassLocation[i] = (float) (centerOfMassLocation[i] + speed[i]*time + (forceSum[i]/mass)*Math.pow(time, 2)/2);
		}
		rotation = (float) (rotation + rotationSpeed*time + torqueSum*Math.pow(time, 2)/2);
	}
	
	
	public void flush() {
		forceSum = new Float[]{0f, 0f};
		torqueSum = 0f;
	}
	public Float[] getForce() {
		return forceSum;
	}
	public Float getTorque() {
		return torqueSum;
	}
	public Float[] getLocation() {
		return centerOfMassLocation;
	}
	public Float getRotation() {
		return rotation;
	}
}

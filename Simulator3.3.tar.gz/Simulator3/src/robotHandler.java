import org.json.*;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class robotHandler {
    private JSONObject robot;
    physicsHandler myPhysicsHandler;
    Float[] robotLocation;
    Float robotRotation;
    Float[][] body;
    Float[][] bodyPoints;
    Float[][] bodyLocations;
    Float[][] bodyPointsLocations;
    Map<String, Float[][]> motors = new HashMap<String, Float[][]>();
    Map<String, Float[]> sensors = new HashMap<String, Float[]>();
    Map<String, Float[]> build = new HashMap<String, Float[]>();
    
    private int maxLength(Float[][] input) {//get the length of longest array in a 2d Float array
    	return Arrays.stream(input).mapToInt(row -> row.length).max().getAsInt();
    }
    private Float[][] clockwiser(Float[][] input){//return the inserted vectors sorted in a clockwise rotational order
    	Float[][] output = new Float[input.length][maxLength(input)];
    	double[] angles = new double[input.length];
    	
    	for(int i=0; i<input.length; i++) {
    		angles[i] = Math.atan2((double) input[i][0], (double) input[i][1]);
    	}
    	
    	Arrays.sort(angles); 
    	for(Float[] point:input) {
    		double angle = Math.atan2(point[0], point[1]);
    		int myIndex = 0;
    		while(angles[myIndex] != angle || output[myIndex][0] != null) {
    			myIndex++;
    		}

    		output[myIndex][0] = point[0];
    		output[myIndex][1] = point[1];
    	}
    	return output;
    }
    private int[][] floatToInteger2D(Float[][] input){//converts 2 dimensional Float array to a 2 dimensional int array (uses Math.round() to round the numbers).
        int[][] output = new int[input.length][maxLength(input)];
        for(int i=0; i<input.length; i++){
            for(int j=0; j<input[i].length; j++){
                output[i][j] = (int) Math.round(input[i][j]);
            }
        }
        return output;
    }
    private Float[] doubleToFloat1D(double[] input){//converts 1 dimensional double array to a 1 dimensional Float array.
        Float[] output = new Float[input.length];
        for(int i=0; i<input.length; i++){
            output[i] = (float) input[i];
        }
        return output;
    }
    private double[] rotateVector(double x, double y, double radians)//rotates a vector by the given amount of radians. The locations of motors are given in the format of {x, y} so they could be rotated.
    {
        double[] result = new double[2];
        result[0] = x * Math.cos(radians) - y * Math.sin(radians);
        result[1] = x * Math.sin(radians) + y * Math.cos(radians);
        return result;
    }
    private Float[][] rotateRobotPoints(Float[][] inputPoints, double radians){//rotates all of the motors by the given amount of radians and returns the result coordinates in the format of {x coordinates, y coordinates}.
        Float [][] output = new Float[inputPoints.length][maxLength(inputPoints)];
        
        for(int i=0; i<inputPoints[0].length; i++){
            Float[] newVector = doubleToFloat1D(rotateVector(inputPoints[0][i],inputPoints[1][i],-radians));
            output[0][i] = newVector[0];
            output[1][i] = newVector[1];
        }
        return output;
    }
    private Float[][] rotateRobot(Float[][] input, double radians){
    	Float [][] output = new Float[input.length][maxLength(input)];
    	for(int i=0; i<input.length; i++) {
    		Float[] newVector = doubleToFloat1D(rotateVector(input[i][0],input[i][1],-radians));
    		output[i][0] = newVector[0];
    		output[i][1] = newVector[1];
    	}
    	return output;
    }
    private void bodyPointsLocationsCalc() {
    	Float[][] points = new Float[motors.size()+sensors.size()][2];
    	int count = 0;
    	Set<String> keys = motors.keySet();
    	for(String key : keys) {
    		points[count] = motors.get(key)[0];
    		count++;
    	}
    	Set<String> keys2 = sensors.keySet();
    	for(String key : keys2) {
    		points[count] = sensors.get(key);
    		count++;
    	}
    	points = clockwiser(points);
    	points = rotateRobot(points, robotRotation);
    	
    	Float[][] points2 = new Float[2][motors.size()+sensors.size()];
    	for(int i=0; i<points.length; i++) {
    		points2[0][i] = points[i][0];
    		points2[1][i] = points[i][1];
    	}
    	
    	
    	for(int i=0; i<points2.length; i++) {
    		for(int j=0; j<maxLength(points2); j++) {
    			points2[i][j] = points2[i][j] + robotLocation[i];
    		}
    	}
    	bodyPointsLocations = points2;
    }
    private void motorsCalc() {
    	Iterator keys = robot.keys();
    	JSONObject centerOfMass;
		try {
			centerOfMass = (JSONObject) robot.get("center of mass");
			JSONArray centerOfMassLocation = (JSONArray) centerOfMass.get("location");
			Float[] COM = {(float) centerOfMassLocation.optDouble(0), (float) centerOfMassLocation.optDouble(1)};
			while(keys.hasNext()) {//get all the motor locations from the JSONObject robot and put them in the HashMap motors in the format of <motorName, {{location x, location y}, {direction x, direction y}}>
	            String key = (String)keys.next();
	            try {
					if (robot.get(key).getClass() == JSONObject.class) {
						JSONObject currentObject = (JSONObject)robot.get(key);
						if(currentObject.getString("type").toString().trim().equals("motor")) {
					        JSONArray location = (JSONArray) currentObject.get("location");
					        Float[] loc = {(float) location.optDouble(0)-COM[0],(float) location.optDouble(1)-COM[1]};
					        JSONArray direction = (JSONArray) currentObject.get("direction");
					        Float[] dir = {(float) direction.optDouble(0),(float) direction.optDouble(1)};
					        motors.put(key, new Float[][]{loc,dir});
						}
						else if(currentObject.getString("type").toString().trim().equals("sensor")) {
							JSONArray location = (JSONArray) currentObject.get("location");
					        Float[] loc = {(float) location.optDouble(0)-COM[0],(float) location.optDouble(1)-COM[1]};
					        sensors.put(key, loc);
						}
					}
				} catch (JSONException e) {
					e.printStackTrace();
				}
	        }
		} catch (JSONException e1) {
			e1.printStackTrace();
		}
    }
    private void update() {
    	robotLocation = myPhysicsHandler.getLocation();
    	robotRotation = myPhysicsHandler.getRotation();
    	
    }
    
    
    public robotHandler() {
    	buildReader myBuildReader = new buildReader();
    	try {
			robot = myBuildReader.reader2("Information/build.json").getJSONObject("robot");
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		} catch (JSONException e1) {
			e1.printStackTrace();
		}
    	robotLocation = new Float[]{1f, 1f};//robots initial location in meters
        robotRotation = (float) Math.PI * 0f;//robots rotation in radians
        JSONObject centerOfMass;
		try {
			centerOfMass = (JSONObject) robot.get("center of mass");
			JSONArray centerOfMassLocation = (JSONArray) centerOfMass.get("location");
			myPhysicsHandler = new physicsHandler((float) centerOfMass.getDouble("mass"), new Float[]{(float) centerOfMassLocation.optDouble(0)+robotLocation[0], (float) centerOfMassLocation.optDouble(1)+robotLocation[1]}, robotRotation);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		motorsCalc();
		update();
    }
    
    
    public int[][] getDisplayPoints(int winWidth, int winHeight, int pixelsPerMeter){
    	bodyPointsLocationsCalc();
    	Float [][] points = bodyPointsLocations.clone();

        for(int i=0; i<points.length; i++){
            for(int j=0; j<points[i].length; j++){
                points[i][j] = points[i][j] * pixelsPerMeter;
            }
        }

        int[][] robotLoc = floatToInteger2D(points);//makes all the location number int so they could be displayed.
        for(int i=0; i<robotLoc[1].length; i++){//flips the y-axis so the 0,0 would be in the bottom left (makes it more logical to look at).
            robotLoc[1][i] = winHeight-robotLoc[1][i];
        }
    	return robotLoc;
    }
    
    public int[] getCOM(int winWidth, int winHeight, int pixelsPerMeter) {
    	Float[] Loc = robotLocation.clone();
    	for(int i=0; i<Loc.length; i++) {
    		Loc[i] = Loc[i]*pixelsPerMeter;
    	}
    	int[] locOut = {(int) Math.round(Loc[0]), winHeight - (int) Math.round(Loc[1])};
    	//System.out.println(Arrays.toString(locOut));
    	return locOut;
    }
    
    public void move(Float time) {
    	myPhysicsHandler.positionCalc(time);
    	myPhysicsHandler.flush();
    	update();
    }
    
    public void foo() {
    	//System.out.println(Arrays.deepToString(motors.get("motor1")));
    	//System.out.println(Arrays.deepToString(motors.get("motor2")));
		myPhysicsHandler.forceAdd(new Float[] {motors.get("motor1")[0][0] + robotLocation[0],motors.get("motor1")[0][1] + robotLocation[1]}, doubleToFloat1D(rotateVector((double) motors.get("motor1")[1][0], (double) motors.get("motor1")[1][1], -robotRotation))); 
		myPhysicsHandler.forceAdd(new Float[] {motors.get("motor2")[0][0] + robotLocation[0],motors.get("motor2")[0][1] + robotLocation[1]}, doubleToFloat1D(rotateVector((double) motors.get("motor2")[1][0], (double) motors.get("motor2")[1][1], -robotRotation)));
    }
}
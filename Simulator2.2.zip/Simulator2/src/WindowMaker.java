import org.json.JSONObject;

import javax.swing.JFrame;

public class WindowMaker extends JFrame implements RobotoInterface, Runnable{
    protected windowDraw myWindowDraw = new windowDraw();
    robotHandler myRobotHandler = new robotHandler();
    Float pixelsPerMeter = 100f;
    JSONObject robot;
    Float[] robotLocation = {2.5f, 2.5f};
    Float robotRotation = (float) Math.PI * 0.25f;//robots rotation in radians

    private int[][] floatToInteger2D(Float[][] input){//converts 2 dimensional Float array to a 2 dimensional int array (uses Math.round() to round the numbers).
        int[][] output = new int[input.length][input[0].length];
        for(int i=0; i<input.length; i++){
            for(int j=0; j<input[i].length; j++){
                output[i][j] = (int) Math.round(input[i][j]);
            }
        }
        return output;
    }

    private Float[] doubleToFloat1D(double[] input){//converts 1 dimensional double array to a 1 dimensional Float array.
        Float[] output = new Float[input.length];
        for(int i=0; i<input.length; i++){
            output[i] = (float) input[i];
        }
        return output;
    }

    private double[] rotateVector(double x, double y, double radians)//rotates a vector by the given amount of radians. The locations of motors are given in the format of {x, y} so they could be rotated.
    {
        double[] result = new double[2];
        result[0] = x * Math.cos(radians) - y * Math.sin(radians);
        result[1] = x * Math.sin(radians) + y * Math.cos(radians);
        return result;
    }

    private Float[][] rotateRobot(Float[][] input, double radians){//rotates all of the motors by the given amount of radians and returns the result coordinates in the format of {x coordinates, y coordinates}.
        Float [][] output = new Float[input.length][input[0].length];
        for(int i=0; i<input[0].length; i++){
            Float[] newVector = doubleToFloat1D(rotateVector(input[0][i],input[1][i],-radians));
            output[0][i] = newVector[0];
            output[1][i] = newVector[1];
        }
        return output;
    }

    public WindowMaker(){
        super();
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(500, 500);
        this.setTitle("Simulator");
        this.setContentPane(myWindowDraw);
        this.setVisible(true);
        this.repaint();
    }

    @Override//no idea what it is for, but it doesn't work without.
    public void setEngine(int index, double state) {

    }

    @Override//no idea what it is for, but it doesn't work without.
    public double getRotation() {
        return 0;
    }

    @Override
    public void run() {
        try {
            Thread.sleep(10);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        myRobotHandler.robot = robot;

        while(true){
            Float points[][] = myRobotHandler.bodyCalc();//gets the motor coordinates from the JSON in the format of {x coordinates, y coordinates}.
            points = rotateRobot(points,robotRotation);//rotates the robot body by teh given amount of radians.

            for(int i=0; i<points.length; i++){
                for(int j=0; j<points[i].length; j++){
                    points[i][j] = (points[i][j] + robotLocation[i]) * pixelsPerMeter;
                }
            }

            int[][] robotLoc = floatToInteger2D(points);//makes all the location number int so they could be displayed.
            for(int i=0; i<robotLoc[1].length; i++){//rotates the y-axis so the 0,0 would be in the bottom left (makes it more logical to look at).
                robotLoc[1][i] = 500-robotLoc[1][i];//500 should be replaced with something more universal (window height probably).
            }

            myWindowDraw.xPoints = robotLoc[0];//gives the polygon points to the windowDraw object.
            myWindowDraw.yPoints = robotLoc[1];
            this.repaint();
        }
    }
}

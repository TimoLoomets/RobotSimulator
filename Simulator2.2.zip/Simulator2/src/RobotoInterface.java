public interface RobotoInterface {
	public void setEngine(int index, double state);
	public double getRotation();
}

import org.json.*;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class robotHandler {
    JSONObject robot;

    public Float[][] bodyCalc(){//Returns the robot body's coordinates as a 2 dimensional Float array in the format {x coordinates, y coordinates}.
        List<Float> xPoints = new ArrayList<>();
        List<Float> yPoints = new ArrayList<>();

        Iterator keys = robot.keys();

        while(keys.hasNext()) {
            String key = (String)keys.next();
            if (robot.get(key).getClass() == JSONObject.class) {
                JSONObject myObject = (JSONObject) robot.get(key);
                JSONArray location = (JSONArray) myObject.get("location");
                xPoints.add(location.optFloat(0));
                yPoints.add(location.optFloat(1));

            }
        }

        Float[] xPointsResult = new Float[xPoints.size()];
        xPointsResult = xPoints.toArray(xPointsResult);
        Float[] yPointsResult = new Float[yPoints.size()];
        yPointsResult = yPoints.toArray(yPointsResult);
        Float[][] result = {xPointsResult,yPointsResult};

        return result;
    }
}
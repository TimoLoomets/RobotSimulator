import org.json.*;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

class buildReader {
    JSONObject reader2(String file) throws FileNotFoundException, JSONException {
        String content = new Scanner(new File(file)).useDelimiter("\\Z").next();
        return new JSONObject(content);
    }
}
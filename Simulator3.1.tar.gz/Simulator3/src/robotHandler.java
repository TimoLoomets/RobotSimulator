import org.json.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public class robotHandler {
    JSONObject robot;
    Float[] robotLocation = {2.5f, 2.5f};
    Float robotRotation = (float) Math.PI * 0f;//robots rotation in radians

    
    private int maxLength(Float[][] input) {//get the length of longest array in a 2d Float array
    	return Arrays.stream(input).mapToInt(row -> row.length).max().getAsInt();
    }
    
    
    private Float[][] clockwiser(Float[][] input){
    	Float[][] output = new Float[input.length][maxLength(input)];
    	double[] angles = new double[input.length];
    	
    	for(int i=0; i<input.length; i++) {
    		angles[i] = Math.atan2((double) input[i][0], (double) input[i][1]);
    	}
    	
    	Arrays.sort(angles); 
    	for(Float[] point:input) {
    		double angle = Math.atan2(point[0], point[1]);
    		int myIndex = (int) Arrays.binarySearch(angles, angle);
    		
    		while(output[myIndex][0] != null){
    			myIndex++;
    		}
    		output[myIndex][0] = point[0];
    		output[myIndex][1] = point[1];
    	}
    	return output;
    }
    
    
    public Float[][] bodyCalc() throws JSONException{//Returns the robot body's coordinates as a 2 dimensional Float array in the format {x coordinates, y coordinates}.
        List<Float> xPoints = new ArrayList<>();
        List<Float> yPoints = new ArrayList<>();
        List<Float[]> points = new ArrayList<>();

        Iterator keys = robot.keys();

        while(keys.hasNext()) {
            String key = (String)keys.next();
            if (robot.get(key).getClass() == JSONObject.class) {
                JSONObject myObject = (JSONObject) robot.get(key);
                JSONArray location = (JSONArray) myObject.get("location");
                Float[] test = {(float) location.optDouble(0),(float) location.optDouble(1)};
                points.add(test);
                //xPoints.add((float) location.optDouble(0));
                //yPoints.add((float) location.optDouble(1));
            }
        } 
        
        Float[][] pointsFinal = new Float[2][points.size()];
        pointsFinal = points.toArray(pointsFinal);
        
        pointsFinal = clockwiser(pointsFinal);
        Float[] xPointsResult = new Float[pointsFinal.length];
        Float[] yPointsResult = new Float[pointsFinal.length];
        for(int i=0; i<pointsFinal.length; i++) {
        	xPointsResult[i] = pointsFinal[i][0];
        	yPointsResult[i] = pointsFinal[i][1];
        }

        Float[][] result = {xPointsResult,yPointsResult};

        return result;
    }
    
    
    private int[][] floatToInteger2D(Float[][] input){//converts 2 dimensional Float array to a 2 dimensional int array (uses Math.round() to round the numbers).
        int[][] output = new int[input.length][maxLength(input)];
        for(int i=0; i<input.length; i++){
            for(int j=0; j<input[i].length; j++){
                output[i][j] = (int) Math.round(input[i][j]);
            }
        }
        return output;
    }
    
    
    private Float[] doubleToFloat1D(double[] input){//converts 1 dimensional double array to a 1 dimensional Float array.
        Float[] output = new Float[input.length];
        for(int i=0; i<input.length; i++){
            output[i] = (float) input[i];
        }
        return output;
    }
    
    
    private double[] rotateVector(double x, double y, double radians)//rotates a vector by the given amount of radians. The locations of motors are given in the format of {x, y} so they could be rotated.
    {
        double[] result = new double[2];
        result[0] = x * Math.cos(radians) - y * Math.sin(radians);
        result[1] = x * Math.sin(radians) + y * Math.cos(radians);
        return result;
    }
    
    
    private Float[][] rotateRobot(Float[][] input, double radians){//rotates all of the motors by the given amount of radians and returns the result coordinates in the format of {x coordinates, y coordinates}.
        Float [][] output = new Float[input.length][maxLength(input)];
        for(int i=0; i<input[0].length; i++){
            Float[] newVector = doubleToFloat1D(rotateVector(input[0][i],input[1][i],-radians));
            output[0][i] = newVector[0];
            output[1][i] = newVector[1];
        }
        return output;
    }
    
    
    public int[][] locationCalc(Float [][] body,int winWidth, int winHeight, int pixelsPerMeter){
    	Float [][] points = rotateRobot(body,robotRotation);//rotates the robot body by the given amount of radians.

        for(int i=0; i<points.length; i++){
            for(int j=0; j<points[i].length; j++){
                points[i][j] = (points[i][j] + robotLocation[i]) * pixelsPerMeter;
            }
        }

        int[][] robotLoc = floatToInteger2D(points);//makes all the location number int so they could be displayed.
        for(int i=0; i<robotLoc[1].length; i++){//rotates the y-axis so the 0,0 would be in the bottom left (makes it more logical to look at).
            robotLoc[1][i] = winHeight-robotLoc[1][i];
        }
    	
    	return robotLoc;
    }
}
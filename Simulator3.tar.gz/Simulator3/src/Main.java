import java.io.FileNotFoundException;

import org.json.JSONException;
import org.json.JSONObject;

public class Main {

	public static void main(String[] args) throws FileNotFoundException, JSONException {
		JSONObject buildInfo = new buildReader().reader2("Information/build.json");
		JSONObject robot = (JSONObject) buildInfo.get("robot");
		windowMaker mainWindow = new windowMaker();
        mainWindow.robot = robot;
        new Thread(mainWindow, "Window").start();
        robotHandler localRobotHandler = new robotHandler();
		// TODO Auto-generated method stub

	}

}

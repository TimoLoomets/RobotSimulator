import javax.swing.JFrame;

import org.json.JSONException;
import org.json.JSONObject;

public class windowMaker extends JFrame implements Runnable{
	protected windowDraw myWindowDraw = new windowDraw();
    robotHandler myRobotHandler = new robotHandler();
    int pixelsPerMeter = 100;
    JSONObject robot;
    
    public windowMaker(){
        super();
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(500, 500);
        this.setTitle("Simulator");
        this.setContentPane(myWindowDraw);
        this.setVisible(true);
        this.repaint();
    }
    

    public void run() {
        try {
            Thread.sleep(10);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        
        myRobotHandler.robot = robot;
        
        while(true) {
        	try {
				Float[][] robotBody = myRobotHandler.bodyCalc();
				int[][] displayPoints = myRobotHandler.locationCalc(robotBody, this.getWidth(), this.getHeight(), pixelsPerMeter);
				myWindowDraw.xPoints = displayPoints[0];
				myWindowDraw.yPoints = displayPoints[1];
			} catch (JSONException e) {
				e.printStackTrace();
			}
        	this.repaint();
        }
    }
}

import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JPanel;

public class windowDraw extends JPanel{
    int[] xPoints = {0,0,0};//This should be changed so that any number of motors would work (not just 3).
    int[] yPoints = {0,0,0};//This should be changed so that any number of motors would work (not just 3).
    int nP = xPoints.length;//I didn't quie understand what this variable are for, but it seems to work like this.


    protected void paintComponent(Graphics g) {
        g.setColor(Color.WHITE);
        g.fillRect(0, 0, this.getWidth(), this.getHeight());
        g.setColor(Color.RED);
        g.fillPolygon(xPoints,yPoints,nP);
    }
}

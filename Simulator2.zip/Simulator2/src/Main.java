import org.json.JSONObject;

import java.io.FileNotFoundException;

@SuppressWarnings("unchecked")
public class Main {
    public static void main(String[] args) throws FileNotFoundException {
        JSONObject buildInfo = new buildReader().reader2("Information/build.json");
        JSONObject robot = (JSONObject) buildInfo.get("robot");
        WindowMaker mainWindow = new WindowMaker();
        mainWindow.robot = robot;
        new Thread(mainWindow, "Window").start();
        robotHandler localRobotHandler = new robotHandler();
        localRobotHandler.robot = robot;
        localRobotHandler.bodyCalc();
        //System.out.print(buildInfo);
    }
}
